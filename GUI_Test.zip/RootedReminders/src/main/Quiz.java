package main;

import java.util.*;

/**
 * Quiz holds a question bank, and chooses a plant based on the answers
 * user gives.
 * 
 * @author Michaela Dent and Amber Lai Hipp
 */
public class Quiz {    
    /**
     * Default constructor for Quiz class.
     */
    public Quiz(Utility util) {        
        // Create list of questions
        //util.loadFile("Questions.txt", "Questions", questions);
        // Load file for plantOptions
        plantOptions = new PlantList("MainPlants.txt", util); 
    }
    
    /**
     * Generates questions for the user to answer and filters plant
     * options based on the user's response.
     */
    public void processAnswers(String answer1, String answer2, String answer3) {
        String output = "";
        // Question 1
        plantOptions.filterList(answer1, "Water");
            
        // Question 2
        // Eliminate plants that are too high maintenance
        plantOptions.filterList(answer2, "Maintenance");
            
        // Question 3
        // Eliminate plants that don't meet light requirements
        plantOptions.filterList(answer3, "Light");
        
        if (plantOptions.getSize() == 0) {
            output = ("Please try again, there were no plants that matched your answers");
            return;
        }

        // Choose a plant randomly from ones left in the list
        Plant chosenPlant = plantOptions.getRandom();
        
        // Display chosenPlant
        output = ("Recommended Plant: " + chosenPlant.getName());
        //}
    }  
    
    //private ArrayList<String> questions = new ArrayList<>(); // List of questions
    private PlantList plantOptions; // array list of plants copy 
}
