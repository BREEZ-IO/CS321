package main;

import java.time.LocalDate;

/**
 * Plant class used to represent an individual plant
 *
 * @author Amber Lai Hipp and Bre McNichols
 */
public class Plant implements Cloneable{
    /**
     * Constructor that creates a plant object with the given information.
     * 
     * @param name the plant's common name.
     * @param sciName the plant's scientific name.
     * @param nickname the plant's nickname given by the user.
     * @param light the light level required by the plant.
     * @param water how often the plant needs to be watered.
     * @param lastWaterDate the last date that the plant was watered.
     * @param mLevel how difficult the plant is to keep alive.
     */
    public Plant(String name, String sciName, String nickname, String light, String water, String lastWaterDate, String mLevel) {
        plantName = name;
        plantSciName = sciName;
        plantNickname = nickname;
        plantLight = light;
        plantWaterInfo = water;
        lastWatered = lastWaterDate;
        maintenanceLevel = mLevel;
    }
    
    /**
     * Constructor that creates a plant object that is a copy of the given plant.
     * 
     * @param p the plant you would like to add to the list.
     */
    public Plant(Plant p) {
        plantName = p.getName();
        plantSciName = p.getSciName();
        plantLight = p.getLightInfo();
        plantWaterInfo = p.getWaterInfo();
        maintenanceLevel = p.getMaintenanceLevel();
    }
    
    /**
     * Gives the common name of the plant.
     * 
     * @return plantName the common name of the plant.
     */
    public String getName() {
        return plantName;
    }
    
    /**
     * Gives the scientific name of the plant.
     * 
     * @return plantSciName the scientific name of the plant.
     */
    public String getSciName() {
        return plantSciName;
    }
    
    /**
     * Gives the nickname of the plant.
     * 
     * @return plantNickname the nickname of the plant.
     */
    public String getNickname() {
        return plantNickname;
    }
    
    /**
     * Changes the nickname of the plant.
     * 
     * @param nickname the nickname to give the plant.
     */
    public void setNickname(String nickname) {
        this.plantNickname = nickname;
    }
    
    /**
     * Gives the plant's light-level needs.
     * 
     * @return plantLight the light level the plant needs - low, indirect, bright.
     */
    public String getLightInfo() {
        return plantLight;
    }
    
    /**
     * Gives the plant's watering schedule.
     * 
     * @return plantWaterInfo the plant's watering schedule in human-understandable
     * format.
     */
    public String getWaterInfo() {
        return plantWaterInfo;
    }
    
    /**
     * Gives the last date the plant was watered.
     * 
     * @return lastWatered the last day the plant was watered.
     */
    public String getLastWateredDate() {
       return lastWatered;
    }
    
    /**
     * Sets the last watered date to the current date.
     */
    public void setLastWateredDate() {
        LocalDate date = LocalDate.now();
        lastWatered = date.toString();
    }
    
    /**
     * Gives the plant's care difficulty.
     * 
     * @return maintenanceLevel how easy the plant is to take care of.
     */
    public String getMaintenanceLevel() {
        return maintenanceLevel;
    }

    /**
     * Gives the number of days between waterings in integer form.
     * 
     * @return the number of days between waterings.
     */
    public int getWaterInfoinDays(){
        if (plantWaterInfo.contains("Once a week")){
            return 7;
        }
        else if (plantWaterInfo.contains("Twice a week")){
            return 3;
        }
        else if (plantWaterInfo.contains("Twice a month")){
            return 14;
        }
        else {
            return 0;
        }
    }
    
    /**
     * Formats the plant's information.
     * 
     * @return a readable string of the plant's information.
     */
    @Override
    public String toString() {
        return String.format("Name: " + plantName + "\nScientific Name: " + plantSciName
                + "\nNickname: " + plantNickname + "\nLight: " + plantLight + "\nWater: " +
                plantWaterInfo + "\nLast Watered: " + lastWatered + "\nMaintenance Level: "
                + maintenanceLevel + "\n\n");
    }
    
    private String plantName;
    private String plantSciName;
    private String plantNickname;
    private String plantLight;
    private String plantWaterInfo;
    private String lastWatered;
    private String maintenanceLevel;
}