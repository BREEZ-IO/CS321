package main;

import java.util.*;

/**
 * Quiz chooses a plant based on the answers provided by the user.
 * user gives.
 * 
 * @author Michaela Dent and Amber Lai Hipp
 */
public class Quiz {    
    /**
     * Default constructor for Quiz class.
     * 
     * @param util the Utility class to load the plantOptions list.
     */
    public Quiz(Utility util) {        
        // Load file for plantOptions
        plantOptions = new PlantList("MainPlants.txt", util); 
    }
    
    /**
     * Filters plant options based on the user's response.
     * 
     * @param answer1 the answer to the first quiz question.
     * @param answer2 the answer to the second quiz question.
     * @param answer3 the answer to the third quiz question.
     * @return output the recommended plant based on the answers given.
     */
    public String processAnswers(String answer1, String answer2, String answer3) {
        String output = "";
        // Question 1
        // Eliminate plants that do not meet water requirements
        plantOptions.filterList(answer1, "Water");
            
        // Question 2
        // Eliminate plants that are too high maintenance
        plantOptions.filterList(answer2, "Maintenance");
            
        // Question 3
        // Eliminate plants that don't meet light requirements
        plantOptions.filterList(answer3, "Light");
        
        // If plantOptions is empty, tell user to try again
        if (plantOptions.getSize() == 0) {
            output = ("Please try again, there were no plants that matched your answers");
            return output;
        }

        // Choose a plant randomly from ones left in the list
        Plant chosenPlant = plantOptions.getRandom();
        
        // Set output to recommended plant name and return
        output = ("Recommended Plant: " + chosenPlant.getName());
        return output;
    }  

    // Array list of plant options
    private PlantList plantOptions; 
}
