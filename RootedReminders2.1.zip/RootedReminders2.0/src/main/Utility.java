package main;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
import java.time.*;

/**
 * A class to load and save files and to check for water reminders.
 * 
 * @author Amber Lai Hipp, Meghan Scott, Bre McNichols
 */
public class Utility {
    /**
     * Constructor
     */
    public Utility() {
        
    }

    /**
     * Loads information from a file into a given ArrayList.
     * 
     * @param fileName the name of the file to load from. 
     * @param aList the list to load the information into.
     */
    public void loadFile(String fileName, ArrayList aList) {
        try {
            FileReader read = new FileReader(fileName);
            Scanner scanner = new Scanner(read); // create scanner
            String line = "";
               
           
                // initialize temp variables
                String tempName = "";
                String tempSciName = "";
                String tempNickname = "";
                String tempLight = "";
                String tempWaterInfo = "";
                String tempLastWaterDate = "";
                String tempMLevel = "";
                                      
                while (scanner.hasNextLine()) { // While there are more lines in the file 
                    tempName = scanner.nextLine(); // set tempName to line read in
                    tempSciName = scanner.nextLine();
                    tempNickname = scanner.nextLine();
                    tempLight = scanner.nextLine();
                    tempWaterInfo = scanner.nextLine();
                    tempLastWaterDate = scanner.nextLine();
                    tempMLevel = scanner.nextLine();
                           
                    line = scanner.nextLine();
                    // Create Plant Object with info
                    Plant p = new Plant(tempName, tempSciName, tempNickname, tempLight, tempWaterInfo, tempLastWaterDate, tempMLevel);
                    // Add plant to arrayList that was passed in
                    aList.add(p);
                }
        }  
        catch (Exception FileNotFoundException) {
            System.out.println("ERROR: File not found.");
            System.exit(0);
        }
    }
    
    /**
     * Saves a list to a file.
     * 
     * @param list the list to be saved.
     */
    public void writeFile(ArrayList<Plant> list) {
        try {            
            FileWriter writer = new FileWriter("MyPlants.txt");
            
            for (Plant p : list) {
                writer.write(p.getName() + "\n");
                writer.write(p.getSciName() + "\n");
                writer.write(p.getNickname() + "\n");
                writer.write(p.getLightInfo() + "\n");
                writer.write(p.getWaterInfo() + "\n");
                writer.write(p.getLastWateredDate() + "\n");
                writer.write(p.getMaintenanceLevel() + "\n");
                writer.write("***************\n");
                
                writer.flush();
            }
            
            writer.close();
            System.out.println("File saved successfully");          
        }
        catch (IOException e) {
            System.out.println("An ERROR occured saving the file.");
            e.printStackTrace();
        }
    }
    
    /**
     * Checks to see if any plants in personal list need to be watered.
     * 
     * @param p list to be checked.
     * @return output a string of the plants that need to be watered.
     */
    public String checkForReminders(PlantList p) {
        LocalDate today = LocalDate.now();
        String output = "";
        for (int i = 0; i < p.getSize(); i++) {
            Plant tempPlant = p.iterateList(i);
            LocalDate lastWatered = LocalDate.parse(tempPlant.getLastWateredDate());
            int waterPeriod = tempPlant.getWaterInfoinDays();
            if (today.minusDays(waterPeriod).compareTo(lastWatered) > 0 
                    || (today.minusDays(waterPeriod).isEqual(lastWatered))) {
                if (tempPlant.getNickname().contains("NULL")) {
                    output += ("Time to water your " + tempPlant.getName() + "\n");
                }
                else {
                    output += ("Time to water your " + tempPlant.getName() + " " + tempPlant.getNickname() + "\n");
                }
               tempPlant.setLastWateredDate();                
            } 
            else
                continue;
        }
        
        if (output.isEmpty()) {
            output = "All of your plants are happy.";
        }
        p.saveList();
        return output;
    }  
}